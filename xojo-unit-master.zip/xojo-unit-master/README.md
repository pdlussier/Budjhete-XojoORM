# xojo-unit
Unit-Test for the Budjhete/Xojo-ORM

This is a mini-app for testing the Xojo-ORM by Les Logiciels Budj'hète inc.
